package com.example.engine

enum class LogType {
    STDOUT,
    STDERR,
    SYSTEM,
    INPUT_PROMPT,
    USER_INPUT
}

data class TerminalLog(
    val message: String,
    val type: LogType,
    val timestamp: Long = System.currentTimeMillis()
)

enum class ExecutionStatus {
    IDLE,
    RUNNING,
    WAITING_FOR_INPUT,
    COMPLETED,
    ERROR
}

data class TerminalState(
    val status: ExecutionStatus = ExecutionStatus.IDLE,
    val logs: List<TerminalLog> = emptyList(),
    val currentPrompt: String = "",
    val executionTimeMs: Long = 0,
    val exitCode: Int = 0
)
