package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Polish Theme Palette
val Blue600 = Color(0xFF2563EB)
val Blue700 = Color(0xFF1D4ED8)
val Blue100 = Color(0xFFDBEAFE)
val Blue50 = Color(0xFFEFF6FF)

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF7F9FC)

// VS Code IDE Canvas Colors
val EditorDarkBg = Color(0xFF1E1E1E)
val EditorLineNumberBg = Color(0xFF1E1E1E)
val EditorLineNumberText = Color(0xFF64748B)

// Syntax Highlighting Colors
val SyntaxKeyword = Color(0xFFC586C0)
val SyntaxBuiltin = Color(0xFFDCDCAA)
val SyntaxString = Color(0xFFCE9178)
val SyntaxNumber = Color(0xFFB5CEA8)
val SyntaxComment = Color(0xFF6A9955)
val SyntaxIdentifier = Color(0xFF9CDCFE)
val SyntaxOperator = Color(0xFFD4D4D4)
val SyntaxDefaultText = Color(0xFFD4D4D4)

