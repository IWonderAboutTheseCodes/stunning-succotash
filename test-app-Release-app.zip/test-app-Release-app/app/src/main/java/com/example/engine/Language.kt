package com.example.engine

enum class Language(val id: String, val displayName: String, val extension: String, val commentPrefix: String) {
    PYTHON("python", "Python", ".py", "#"),
    PSEUDOCODE("pseudocode", "Pseudocode", ".pseudo", "//"),
    LUA("lua", "Lua", ".lua", "--");

    companion object {
        fun fromId(id: String): Language {
            return values().find { it.id.equals(id, ignoreCase = true) } ?: PYTHON
        }
    }
}
