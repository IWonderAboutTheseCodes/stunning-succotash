package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardTab
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.Language

@Composable
fun QuickSymbolBar(
    language: Language,
    onInsertSymbol: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val commonSymbols = listOf("(", ")", ":", "=", "==", "\"", "'", "+", "-", "*", "/", "[", "]", "{", "}", ",")
    val languageSymbols = when (language) {
        Language.PYTHON -> listOf("#", "f\"", "def ", "return ", "if ", "for ", "in ", "range(")
        Language.PSEUDOCODE -> listOf("//", "<-", "DISPLAY ", "SET ", "INPUT ", "IF ", "THEN", "END IF")
        Language.LUA -> listOf("--", "..", "local ", "print(", "then", "end", "function ")
    }

    val allSymbols = commonSymbols + languageSymbols

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tab key button
            Surface(
                onClick = { onInsertSymbol("    ") },
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("symbol_tab_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardTab,
                    contentDescription = "Insert Tab Indent",
                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(6.dp)
                )
            }

            allSymbols.forEachIndexed { idx, symbol ->
                Surface(
                    onClick = { onInsertSymbol(symbol) },
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.testTag("symbol_btn_$idx")
                ) {
                    Text(
                        text = symbol,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}
