package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ScriptEntity
import com.example.data.ScriptRepository
import com.example.engine.ExecutionStatus
import com.example.engine.Interpreter
import com.example.engine.Language
import com.example.engine.LogType
import com.example.engine.TerminalLog
import com.example.engine.TerminalState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CodeEditorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ScriptRepository
    val allScripts: StateFlow<List<ScriptEntity>>

    private val _activeScript = MutableStateFlow<ScriptEntity?>(null)
    val activeScript: StateFlow<ScriptEntity?> = _activeScript.asStateFlow()

    private val _codeText = MutableStateFlow("")
    val codeText: StateFlow<String> = _codeText.asStateFlow()

    private val _currentLanguage = MutableStateFlow(Language.PYTHON)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    private val _terminalState = MutableStateFlow(TerminalState())
    val terminalState: StateFlow<TerminalState> = _terminalState.asStateFlow()

    private var executionJob: Job? = null
    private var inputDeferred: CompletableDeferred<String>? = null

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ScriptRepository(database.scriptDao())
        allScripts = repository.allScripts.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Auto-select initial script when loaded from Room
        viewModelScope.launch {
            allScripts.collect { scripts ->
                if (_activeScript.value == null && scripts.isNotEmpty()) {
                    selectScript(scripts.first())
                }
            }
        }
    }

    fun selectScript(script: ScriptEntity) {
        _activeScript.value = script
        _codeText.value = script.code
        _currentLanguage.value = Language.fromId(script.language)
    }

    fun updateCodeText(newText: String) {
        _codeText.value = newText
        _activeScript.value?.let { current ->
            viewModelScope.launch {
                val updated = current.copy(
                    code = newText,
                    updatedAt = System.currentTimeMillis()
                )
                repository.update(updated)
                _activeScript.value = updated
            }
        }
    }

    fun selectLanguage(language: Language) {
        _currentLanguage.value = language
        _activeScript.value?.let { current ->
            viewModelScope.launch {
                val updated = current.copy(
                    language = language.id,
                    updatedAt = System.currentTimeMillis()
                )
                repository.update(updated)
                _activeScript.value = updated
            }
        }
    }

    fun createNewScript(title: String, language: Language, initialCode: String = "") {
        val defaultCode = if (initialCode.isNotBlank()) initialCode else when (language) {
            Language.PYTHON -> "# New Python Script\nprint(\"Hello, Python!\")\n"
            Language.PSEUDOCODE -> "// New Pseudocode Script\nDISPLAY \"Hello, World!\"\n"
            Language.LUA -> "-- New Lua Script\nprint(\"Hello, Lua!\")\n"
        }

        val newEntity = ScriptEntity(
            title = title,
            language = language.id,
            code = defaultCode
        )

        viewModelScope.launch {
            val id = repository.insert(newEntity)
            val created = newEntity.copy(id = id.toInt())
            selectScript(created)
        }
    }

    fun renameScript(script: ScriptEntity, newTitle: String) {
        viewModelScope.launch {
            val updated = script.copy(
                title = newTitle,
                updatedAt = System.currentTimeMillis()
            )
            repository.update(updated)
            if (_activeScript.value?.id == script.id) {
                _activeScript.value = updated
            }
        }
    }

    fun deleteScript(script: ScriptEntity) {
        viewModelScope.launch {
            repository.delete(script)
            if (_activeScript.value?.id == script.id) {
                _activeScript.value = null
            }
        }
    }

    // ==========================================
    // SCRIPT RUNNER / TERMINAL ENGINE
    // ==========================================
    fun runScript() {
        stopScript() // Stop previous execution if any

        val code = _codeText.value
        val lang = _currentLanguage.value

        _terminalState.value = TerminalState(
            status = ExecutionStatus.RUNNING,
            logs = listOf(
                TerminalLog("=== Running ${lang.displayName} Script ===", LogType.SYSTEM)
            )
        )

        val interpreter = Interpreter(
            onOutput = { msg, type ->
                addTerminalLog(msg, type)
            },
            onRequestInput = { prompt ->
                _terminalState.value = _terminalState.value.copy(
                    status = ExecutionStatus.WAITING_FOR_INPUT,
                    currentPrompt = prompt
                )
                val deferred = CompletableDeferred<String>()
                inputDeferred = deferred
                deferred.await()
            }
        )

        executionJob = viewModelScope.launch {
            val exitCode = interpreter.execute(code, lang)
            val finalStatus = if (exitCode == 0) ExecutionStatus.COMPLETED else ExecutionStatus.ERROR
            _terminalState.value = _terminalState.value.copy(
                status = finalStatus,
                exitCode = exitCode
            )
        }
    }

    fun submitUserInput(input: String) {
        inputDeferred?.let { deferred ->
            if (deferred.isActive) {
                deferred.complete(input)
                _terminalState.value = _terminalState.value.copy(
                    status = ExecutionStatus.RUNNING,
                    currentPrompt = ""
                )
            }
        }
    }

    fun stopScript() {
        executionJob?.cancel()
        inputDeferred?.cancel()
        if (_terminalState.value.status == ExecutionStatus.RUNNING || _terminalState.value.status == ExecutionStatus.WAITING_FOR_INPUT) {
            addTerminalLog("[Execution stopped by user]", LogType.SYSTEM)
            _terminalState.value = _terminalState.value.copy(status = ExecutionStatus.IDLE)
        }
    }

    fun clearTerminal() {
        _terminalState.value = TerminalState()
    }

    private fun addTerminalLog(message: String, type: LogType) {
        val currentLogs = _terminalState.value.logs.toMutableList()
        currentLogs.add(TerminalLog(message, type))
        _terminalState.value = _terminalState.value.copy(logs = currentLogs)
    }
}
