package com.example.engine

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import java.util.regex.Pattern

class SyntaxHighlighter(
    val language: Language,
    val isDarkTheme: Boolean = true
) : VisualTransformation {

    // Palette Definition (VS Code Dark Theme Palette)
    private val keywordColor = Color(0xFFC586C0)   // Purple
    private val builtinColor = Color(0xFFDCDCAA)   // Yellow/Gold
    private val stringColor = Color(0xFFCE9178)    // Coral/Orange
    private val numberColor = Color(0xFFB5CEA8)    // Light Green
    private val commentColor = Color(0xFF6A9955)   // Forest Green
    private val operatorColor = Color(0xFFD4D4D4)  // Slate Light
    private val defaultTextColor = Color(0xFFD4D4D4)

    override fun filter(text: AnnotatedString): TransformedText {
        return TransformedText(
            highlightCode(text.text, language),
            OffsetMapping.Identity
        )
    }

    fun highlightCode(code: String, lang: Language): AnnotatedString {
        return buildAnnotatedString {
            append(code)

            if (code.isEmpty()) return@buildAnnotatedString

            val length = code.length

            when (lang) {
                Language.PYTHON -> highlightPython(code, length)
                Language.LUA -> highlightLua(code, length)
                Language.PSEUDOCODE -> highlightPseudocode(code, length)
            }
        }
    }

    private fun AnnotatedString.Builder.highlightPython(code: String, length: Int) {
        val keywords = setOf(
            "def", "class", "if", "elif", "else", "while", "for", "in", "return", "import",
            "from", "as", "try", "except", "finally", "raise", "with", "lambda", "pass",
            "break", "continue", "and", "or", "not", "is", "None", "True", "False", "yield",
            "global", "nonlocal", "async", "await"
        )
        val builtins = setOf(
            "print", "input", "len", "range", "int", "float", "str", "list", "dict", "set",
            "tuple", "sum", "max", "min", "abs", "type", "append", "join", "split", "format",
            "open", "enumerate", "zip", "map", "filter", "round", "sorted", "reversed"
        )

        applyRegexHighlights(
            code = code,
            commentPattern = Pattern.compile("#.*"),
            stringPattern = Pattern.compile("\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''|\"[^\"]*\"|'[^']*'"),
            keywords = keywords,
            builtins = builtins,
            operatorsPattern = Pattern.compile("[=+\\-*/%<>!&|^~:]")
        )
    }

    private fun AnnotatedString.Builder.highlightLua(code: String, length: Int) {
        val keywords = setOf(
            "and", "break", "do", "else", "elseif", "end", "false", "for", "function", "if",
            "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while"
        )
        val builtins = setOf(
            "print", "type", "tostring", "tonumber", "ipairs", "pairs", "next", "select",
            "require", "rawget", "rawset", "error", "pcall", "xpcall", "assert", "collectgarbage",
            "math", "string", "table", "io", "os"
        )

        applyRegexHighlights(
            code = code,
            commentPattern = Pattern.compile("--\\[\\[[\\s\\S]*?\\]\\]|--.*"),
            stringPattern = Pattern.compile("\\[\\[[\\s\\S]*?\\]\\]|\"[^\"]*\"|'[^']*'"),
            keywords = keywords,
            builtins = builtins,
            operatorsPattern = Pattern.compile("[=+\\-*/%<>~#..]")
        )
    }

    private fun AnnotatedString.Builder.highlightPseudocode(code: String, length: Int) {
        val keywords = setOf(
            "DECLARE", "AS", "SET", "TO", "IF", "THEN", "ELSE IF", "ELSE", "END IF",
            "FOR", "FROM", "TO", "STEP", "DO", "END FOR", "WHILE", "END WHILE",
            "REPEAT", "UNTIL", "FUNCTION", "RETURN", "END FUNCTION", "PROCEDURE",
            "END PROCEDURE", "AND", "OR", "NOT", "TRUE", "FALSE", "INTEGER", "REAL",
            "STRING", "BOOLEAN", "ARRAY", "LIST", "EACH", "IN"
        )
        val builtins = setOf(
            "DISPLAY", "PRINT", "OUTPUT", "INPUT", "READ", "LENGTH", "RANDOM",
            "SQRT", "ROUND", "APPEND", "POP", "INSERT", "REMOVE"
        )

        applyRegexHighlights(
            code = code,
            commentPattern = Pattern.compile("//.*|/\\*[\\s\\S]*?\\*/"),
            stringPattern = Pattern.compile("\"[^\"]*\"|'[^']*'"),
            keywords = keywords,
            builtins = builtins,
            operatorsPattern = Pattern.compile("(<-)|[=+\\-*/%<>!]")
        )
    }

    private fun AnnotatedString.Builder.applyRegexHighlights(
        code: String,
        commentPattern: Pattern,
        stringPattern: Pattern,
        keywords: Set<String>,
        builtins: Set<String>,
        operatorsPattern: Pattern
    ) {
        val length = code.length

        // Track highlighted ranges to prevent comment/string tokens from being overridden
        val processed = BooleanArray(length)

        // 1. Comments
        val commentMatcher = commentPattern.matcher(code)
        while (commentMatcher.find()) {
            val start = commentMatcher.start()
            val end = commentMatcher.end()
            addStyle(
                SpanStyle(color = commentColor, fontWeight = FontWeight.Normal),
                start,
                end
            )
            for (i in start until end) processed[i] = true
        }

        // 2. Strings
        val stringMatcher = stringPattern.matcher(code)
        while (stringMatcher.find()) {
            val start = stringMatcher.start()
            val end = stringMatcher.end()
            if ((start until end).none { processed[it] }) {
                addStyle(
                    SpanStyle(color = stringColor, fontWeight = FontWeight.Medium),
                    start,
                    end
                )
                for (i in start until end) processed[i] = true
            }
        }

        // 3. Numbers
        val numberPattern = Pattern.compile("\\b\\d+(\\.\\d+)?\\b")
        val numberMatcher = numberPattern.matcher(code)
        while (numberMatcher.find()) {
            val start = numberMatcher.start()
            val end = numberMatcher.end()
            if ((start until end).none { processed[it] }) {
                addStyle(
                    SpanStyle(color = numberColor, fontWeight = FontWeight.SemiBold),
                    start,
                    end
                )
                for (i in start until end) processed[i] = true
            }
        }

        // 4. Word Tokens (Keywords & Builtins)
        val wordPattern = Pattern.compile("\\b[a-zA-Z_][a-zA-Z0-9_]*\\b")
        val wordMatcher = wordPattern.matcher(code)
        while (wordMatcher.find()) {
            val start = wordMatcher.start()
            val end = wordMatcher.end()
            if ((start until end).none { processed[it] }) {
                val word = code.substring(start, end)
                val isUpperKey = language == Language.PSEUDOCODE && keywords.contains(word.uppercase())
                val isCaseMatchKey = keywords.contains(word)
                val isUpperBuiltin = language == Language.PSEUDOCODE && builtins.contains(word.uppercase())
                val isCaseMatchBuiltin = builtins.contains(word)

                if (isUpperKey || isCaseMatchKey) {
                    addStyle(
                        SpanStyle(color = keywordColor, fontWeight = FontWeight.Bold),
                        start,
                        end
                    )
                } else if (isUpperBuiltin || isCaseMatchBuiltin) {
                    addStyle(
                        SpanStyle(color = builtinColor, fontWeight = FontWeight.Medium),
                        start,
                        end
                    )
                }
            }
        }

        // 5. Operators
        val opMatcher = operatorsPattern.matcher(code)
        while (opMatcher.find()) {
            val start = opMatcher.start()
            val end = opMatcher.end()
            if ((start until end).none { processed[it] }) {
                addStyle(
                    SpanStyle(color = operatorColor, fontWeight = FontWeight.Bold),
                    start,
                    end
                )
            }
        }
    }
}
