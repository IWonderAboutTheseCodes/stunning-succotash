package com.example.data

import kotlinx.coroutines.flow.Flow

class ScriptRepository(private val scriptDao: ScriptDao) {
    val allScripts: Flow<List<ScriptEntity>> = scriptDao.getAllScripts()

    fun getScriptById(id: Int): Flow<ScriptEntity?> = scriptDao.getScriptById(id)

    suspend fun insert(script: ScriptEntity): Long = scriptDao.insertScript(script)

    suspend fun update(script: ScriptEntity) = scriptDao.updateScript(script)

    suspend fun delete(script: ScriptEntity) = scriptDao.deleteScript(script)

    suspend fun deleteById(id: Int) = scriptDao.deleteScriptById(id)
}
