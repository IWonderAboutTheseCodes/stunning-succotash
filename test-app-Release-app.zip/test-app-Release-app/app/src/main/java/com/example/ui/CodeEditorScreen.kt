package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.Language
import com.example.engine.SyntaxHighlighter
import com.example.ui.components.CodeTemplatesDialog
import com.example.ui.components.LineNumbers
import com.example.ui.components.QuickSymbolBar
import com.example.ui.components.ScriptListDrawer
import com.example.ui.components.TerminalConsole
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CodeEditorScreen(
    viewModel: CodeEditorViewModel,
    modifier: Modifier = Modifier
) {
    val activeScript by viewModel.activeScript.collectAsStateWithLifecycle()
    val allScripts by viewModel.allScripts.collectAsStateWithLifecycle()
    val codeText by viewModel.codeText.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val terminalState by viewModel.terminalState.collectAsStateWithLifecycle()

    var showScriptDrawer by remember { mutableStateOf(false) }
    var showTemplatesDialog by remember { mutableStateOf(false) }
    var isTerminalExpanded by remember { mutableStateOf(true) }
    var showLanguageDropdown by remember { mutableStateOf(false) }

    val sheetState = rememberModalBottomSheetState()
    val scope = rememberCoroutineScope()

    // TextField State with Cursor Control
    var textFieldValue by remember(activeScript?.id) {
        mutableStateOf(TextFieldValue(text = codeText, selection = TextRange(codeText.length)))
    }

    // Keep TextFieldValue in sync with viewModel code text updates
    if (textFieldValue.text != codeText) {
        textFieldValue = textFieldValue.copy(text = codeText)
    }

    val isDark = true
    val highlighter = remember(currentLanguage, isDark) {
        SyntaxHighlighter(currentLanguage, isDark)
    }

    val editorBg = Color(0xFF1E1E1E)
    val editorTextColor = Color(0xFFD4D4D4)
    val topBarBorderColor = Color(0xFFE2E8F0)

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(
                                    text = activeScript?.title ?: "main.py",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF0F172A),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = when (currentLanguage) {
                                        Language.PYTHON -> "Python 3.11"
                                        Language.LUA -> "Lua 5.4"
                                        Language.PSEUDOCODE -> "Pseudocode 1.0"
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF64748B),
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { showScriptDrawer = true },
                            modifier = Modifier.testTag("open_scripts_drawer_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = "Script Files",
                                tint = Color(0xFF475569)
                            )
                        }
                    },
                    actions = {
                        // Play Button in Top Bar (Design Matching: Soft blue circle with dark blue play arrow)
                        Surface(
                            onClick = {
                                isTerminalExpanded = true
                                viewModel.runScript()
                            },
                            shape = CircleShape,
                            color = Color(0xFFDBEAFE),
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .size(36.dp)
                                .testTag("run_script_top_btn")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Run Script",
                                    tint = Color(0xFF1D4ED8),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.White
                    )
                )

                // Language Selection Toolbar (Horizontal Pill Row matching design)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Language.values().forEach { lang ->
                        val isSelected = currentLanguage == lang
                        Surface(
                            onClick = { viewModel.selectLanguage(lang) },
                            shape = CircleShape,
                            color = if (isSelected) Color(0xFF2563EB) else Color(0xFFF1F5F9),
                            modifier = Modifier.testTag("lang_chip_${lang.id}")
                        ) {
                            Text(
                                text = lang.displayName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isSelected) Color.White else Color(0xFF475569),
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(topBarBorderColor)
                )
            }
        },
        bottomBar = {
            // Bottom Navigation Footer matching Professional Polish design
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.White,
                shadowElevation = 4.dp
            ) {
                Column {
                    Spacer(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(topBarBorderColor)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Editor Nav Button
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                                .testTag("nav_editor")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = "Editor",
                                tint = Color(0xFF2563EB),
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = "Editor",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF2563EB)
                            )
                        }

                        // Files Nav Button
                        Surface(
                            onClick = { showScriptDrawer = true },
                            color = Color.Transparent,
                            modifier = Modifier.testTag("nav_files")
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Folder,
                                    contentDescription = "Files",
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = "Files",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }

                        // Templates Nav Button
                        Surface(
                            onClick = { showTemplatesDialog = true },
                            color = Color.Transparent,
                            modifier = Modifier.testTag("nav_templates")
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lightbulb,
                                    contentDescription = "Templates",
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = "Templates",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }

                        // Shell / Terminal Nav Button
                        Surface(
                            onClick = { isTerminalExpanded = !isTerminalExpanded },
                            color = Color.Transparent,
                            modifier = Modifier.testTag("nav_terminal")
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Terminal,
                                    contentDescription = "Shell",
                                    tint = if (isTerminalExpanded) Color(0xFF2563EB) else Color(0xFF64748B),
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = "Terminal",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (isTerminalExpanded) Color(0xFF2563EB) else Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    isTerminalExpanded = true
                    viewModel.runScript()
                },
                containerColor = Color(0xFF2563EB),
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.testTag("run_script_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Run Script"
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(editorBg)
        ) {
            // Main Editor Canvas (Line Numbers + Code Input Area)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(if (isTerminalExpanded) 0.55f else 0.95f)
            ) {
                val lineCount = codeText.lines().size

                LineNumbers(
                    lineCount = lineCount,
                    backgroundColor = Color(0xFF1E1E1E),
                    textColor = Color(0xFF64748B)
                )

                // Scrollable Code Editor Area
                val verticalScrollState = rememberScrollState()
                val horizontalScrollState = rememberScrollState()

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                        .background(editorBg)
                        .verticalScroll(verticalScrollState)
                        .horizontalScroll(horizontalScrollState)
                        .padding(12.dp)
                ) {
                    BasicTextField(
                        value = textFieldValue,
                        onValueChange = { newValue ->
                            textFieldValue = newValue
                            viewModel.updateCodeText(newValue.text)
                        },
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = editorTextColor,
                            lineHeight = 20.sp
                        ),
                        cursorBrush = SolidColor(Color(0xFF60A5FA)),
                        visualTransformation = highlighter,
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("code_editor_text_field")
                    )
                }
            }

            // Quick Symbol Toolbar
            QuickSymbolBar(
                language = currentLanguage,
                onInsertSymbol = { symbol ->
                    val text = textFieldValue.text
                    val selection = textFieldValue.selection
                    val start = selection.min.coerceIn(0, text.length)
                    val end = selection.max.coerceIn(0, text.length)

                    val newText = text.replaceRange(start, end, symbol)
                    val newCursor = start + symbol.length

                    textFieldValue = TextFieldValue(
                        text = newText,
                        selection = TextRange(newCursor)
                    )
                    viewModel.updateCodeText(newText)
                }
            )

            // Built-in Terminal Console Panel
            TerminalConsole(
                terminalState = terminalState,
                language = currentLanguage,
                onRunScript = { viewModel.runScript() },
                onStopScript = { viewModel.stopScript() },
                onClearTerminal = { viewModel.clearTerminal() },
                onSubmitInput = { input -> viewModel.submitUserInput(input) },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(if (isTerminalExpanded) 0.45f else 0.05f)
            )
        }
    }

    // Bottom Sheet: Script List Drawer
    if (showScriptDrawer) {
        ScriptListDrawer(
            scripts = allScripts,
            activeScriptId = activeScript?.id ?: -1,
            sheetState = sheetState,
            onDismiss = { showScriptDrawer = false },
            onSelectScript = { script ->
                viewModel.selectScript(script)
            },
            onCreateNewScript = { title, lang ->
                viewModel.createNewScript(title, lang)
            },
            onRenameScript = { script, newTitle ->
                viewModel.renameScript(script, newTitle)
            },
            onDeleteScript = { script ->
                viewModel.deleteScript(script)
            },
            onOpenTemplates = {
                showTemplatesDialog = true
            }
        )
    }

    // Dialog: Code Templates Picker
    if (showTemplatesDialog) {
        CodeTemplatesDialog(
            onDismiss = { showTemplatesDialog = false },
            onSelectTemplate = { template ->
                viewModel.createNewScript(
                    title = template.title,
                    language = template.language,
                    initialCode = template.code
                )
            }
        )
    }
}
