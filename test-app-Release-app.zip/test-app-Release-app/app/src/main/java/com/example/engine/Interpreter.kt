package com.example.engine

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.regex.Pattern

class Interpreter(
    private val onOutput: (String, LogType) -> Unit,
    private val onRequestInput: suspend (prompt: String) -> String
) {

    suspend fun execute(code: String, language: Language): Int = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        try {
            onOutput("Starting ${language.displayName} runtime environment...", LogType.SYSTEM)
            when (language) {
                Language.PYTHON -> runPython(code)
                Language.PSEUDOCODE -> runPseudocode(code)
                Language.LUA -> runLua(code)
            }
            val elapsed = System.currentTimeMillis() - startTime
            onOutput("\n[Process finished with exit code 0 in ${elapsed}ms]", LogType.SYSTEM)
            return@withContext 0
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - startTime
            val errorMsg = e.message ?: "Runtime Exception occurred"
            onOutput("Traceback (most recent call):\nError: $errorMsg", LogType.STDERR)
            onOutput("[Process terminated with exit code 1 in ${elapsed}ms]", LogType.SYSTEM)
            return@withContext 1
        }
    }

    // ==========================================
    // PYTHON INTERPRETER
    // ==========================================
    private suspend fun runPython(code: String) {
        val lines = code.lines()
        val env = HashMap<String, Any?>()
        val functions = HashMap<String, Pair<List<String>, List<String>>>() // name -> (args, bodyLines)

        var i = 0
        while (i < lines.size) {
            val rawLine = lines[i]
            val line = rawLine.trim()

            // Skip comments & empty lines
            if (line.isEmpty() || line.startsWith("#")) {
                i++
                continue
            }

            // Function Definition: def func_name(a, b):
            if (line.startsWith("def ")) {
                val match = Pattern.compile("def\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\((.*?)\\):").matcher(line)
                if (match.find()) {
                    val fnName = match.group(1) ?: "func"
                    val fnArgs = match.group(2)?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
                    val fnBody = mutableListOf<String>()

                    i++
                    while (i < lines.size && (lines[i].startsWith("    ") || lines[i].startsWith("\t") || lines[i].isBlank())) {
                        if (lines[i].isNotBlank()) {
                            fnBody.add(lines[i])
                        }
                        i++
                    }
                    functions[fnName] = Pair(fnArgs, fnBody)
                    continue
                }
            }

            // Print Statement: print(...)
            if (line.startsWith("print(") && line.endsWith(")")) {
                val expr = line.substring(6, line.length - 1).trim()
                val evaluated = evaluatePythonExpr(expr, env, functions)
                onOutput(formatOutput(evaluated), LogType.STDOUT)
                i++
                continue
            }

            // For Loop: for i in range(a, b): or for item in list:
            if (line.startsWith("for ") && line.contains(" in ") && line.endsWith(":")) {
                val forHeader = line.substring(4, line.length - 1).trim()
                val parts = forHeader.split(" in ")
                if (parts.size == 2) {
                    val varName = parts[0].trim()
                    val iterableExpr = parts[1].trim()

                    val loopBody = mutableListOf<String>()
                    var j = i + 1
                    while (j < lines.size && (lines[j].startsWith("    ") || lines[j].startsWith("\t") || lines[j].isBlank())) {
                        if (lines[j].isNotBlank()) {
                            loopBody.add(lines[j])
                        }
                        j++
                    }

                    val items = evaluateIterable(iterableExpr, env, functions)
                    for (item in items) {
                        env[varName] = item
                        executeBlockPython(loopBody, env, functions)
                    }
                    i = j
                    continue
                }
            }

            // While Loop: while condition:
            if (line.startsWith("while ") && line.endsWith(":")) {
                val conditionExpr = line.substring(6, line.length - 1).trim()
                val loopBody = mutableListOf<String>()
                var j = i + 1
                while (j < lines.size && (lines[j].startsWith("    ") || lines[j].startsWith("\t") || lines[j].isBlank())) {
                    if (lines[j].isNotBlank()) {
                        loopBody.add(lines[j])
                    }
                    j++
                }

                var maxIterations = 1000
                while (isTruthy(evaluatePythonExpr(conditionExpr, env, functions)) && maxIterations-- > 0) {
                    executeBlockPython(loopBody, env, functions)
                }
                i = j
                continue
            }

            // If / Elif / Else block
            if (line.startsWith("if ") && line.endsWith(":")) {
                val ifCond = line.substring(3, line.length - 1).trim()
                val ifBody = mutableListOf<String>()
                var j = i + 1
                while (j < lines.size && (lines[j].startsWith("    ") || lines[j].startsWith("\t") || lines[j].isBlank())) {
                    if (lines[j].isNotBlank()) {
                        ifBody.add(lines[j])
                    }
                    j++
                }

                if (isTruthy(evaluatePythonExpr(ifCond, env, functions))) {
                    executeBlockPython(ifBody, env, functions)
                }
                i = j
                continue
            }

            // Variable Assignment or Interactive Input: x = input("prompt")
            if (line.contains("=") && !line.startsWith("if") && !line.startsWith("while")) {
                val eqIdx = line.indexOf("=")
                val varName = line.substring(0, eqIdx).trim()
                val valExpr = line.substring(eqIdx + 1).trim()

                if (valExpr.startsWith("input(") && valExpr.endsWith(")")) {
                    var promptText = valExpr.substring(6, valExpr.length - 1).trim()
                    if (promptText.startsWith("\"") || promptText.startsWith("'")) {
                        promptText = promptText.substring(1, promptText.length - 1)
                    }
                    onOutput(promptText, LogType.INPUT_PROMPT)
                    val userInput = onRequestInput(promptText)
                    onOutput(userInput, LogType.USER_INPUT)
                    env[varName] = userInput
                } else {
                    val evaluated = evaluatePythonExpr(valExpr, env, functions)
                    env[varName] = evaluated
                }
                i++
                continue
            }

            // Direct Function Call
            if (line.contains("(") && line.endsWith(")")) {
                evaluatePythonExpr(line, env, functions)
            }

            i++
        }
    }

    private suspend fun executeBlockPython(
        lines: List<String>,
        env: MutableMap<String, Any?>,
        functions: Map<String, Pair<List<String>, List<String>>>
    ) {
        val blockCode = lines.joinToString("\n") { it.trimStart() }
        runPythonSubBlock(blockCode, env, functions)
    }

    private suspend fun runPythonSubBlock(
        code: String,
        env: MutableMap<String, Any?>,
        functions: Map<String, Pair<List<String>, List<String>>>
    ) {
        val lines = code.lines()
        var i = 0
        while (i < lines.size) {
            val line = lines[i].trim()
            if (line.isEmpty() || line.startsWith("#")) {
                i++
                continue
            }
            if (line.startsWith("print(") && line.endsWith(")")) {
                val expr = line.substring(6, line.length - 1).trim()
                val evaluated = evaluatePythonExpr(expr, env, functions)
                onOutput(formatOutput(evaluated), LogType.STDOUT)
            } else if (line.contains("=") && !line.contains("==")) {
                val eqIdx = line.indexOf("=")
                val varName = line.substring(0, eqIdx).trim()
                val valExpr = line.substring(eqIdx + 1).trim()
                if (valExpr.startsWith("input(") && valExpr.endsWith(")")) {
                    var promptText = valExpr.substring(6, valExpr.length - 1).trim()
                    if (promptText.startsWith("\"") || promptText.startsWith("'")) {
                        promptText = promptText.substring(1, promptText.length - 1)
                    }
                    onOutput(promptText, LogType.INPUT_PROMPT)
                    val userInput = onRequestInput(promptText)
                    onOutput(userInput, LogType.USER_INPUT)
                    env[varName] = userInput
                } else {
                    env[varName] = evaluatePythonExpr(valExpr, env, functions)
                }
            } else if (line.startsWith("append(") || line.contains(".append(")) {
                val dotIdx = line.indexOf(".append(")
                if (dotIdx > 0) {
                    val listName = line.substring(0, dotIdx).trim()
                    val argExpr = line.substring(dotIdx + 8, line.length - 1).trim()
                    val listObj = env[listName]
                    if (listObj is MutableList<*>) {
                        @Suppress("UNCHECKED_CAST")
                        (listObj as MutableList<Any?>).add(evaluatePythonExpr(argExpr, env, functions))
                    }
                }
            }
            i++
        }
    }

    private fun evaluateIterable(
        expr: String,
        env: Map<String, Any?>,
        functions: Map<String, Pair<List<String>, List<String>>>
    ): List<Any?> {
        if (expr.startsWith("range(") && expr.endsWith(")")) {
            val argsStr = expr.substring(6, expr.length - 1)
            val args = argsStr.split(",").map { evaluatePythonExpr(it.trim(), env, functions) }
            val start = if (args.size > 1) (args[0] as? Number)?.toInt() ?: 0 else 0
            val end = if (args.size > 1) (args[1] as? Number)?.toInt() ?: 0 else (args.getOrNull(0) as? Number)?.toInt() ?: 0
            val step = if (args.size > 2) (args[2] as? Number)?.toInt() ?: 1 else 1
            val result = mutableListOf<Int>()
            var cur = start
            while (if (step > 0) cur < end else cur > end) {
                result.add(cur)
                cur += step
            }
            return result
        }
        val evaluated = evaluatePythonExpr(expr, env, functions)
        if (evaluated is List<*>) return evaluated
        return emptyList()
    }

    private fun evaluatePythonExpr(
        expr: String,
        env: Map<String, Any?>,
        functions: Map<String, Pair<List<String>, List<String>>>
    ): Any? {
        val trimmed = expr.trim()
        if (trimmed.isEmpty()) return ""

        // String literal
        if ((trimmed.startsWith("\"") && trimmed.endsWith("\"")) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
            return trimmed.substring(1, trimmed.length - 1)
        }

        // F-string: f"Hello, {name}!"
        if (trimmed.startsWith("f\"") && trimmed.endsWith("\"")) {
            val raw = trimmed.substring(2, trimmed.length - 1)
            return raw.replace(Regex("\\{(.*?)\\}")) { match ->
                val innerExpr = match.groupValues[1]
                evaluatePythonExpr(innerExpr, env, functions)?.toString() ?: ""
            }
        }

        // Numbers
        trimmed.toLongOrNull()?.let { return it }
        trimmed.toDoubleOrNull()?.let { return it }
        if (trimmed == "True") return true
        if (trimmed == "False") return false
        if (trimmed == "None") return null

        // List literal: [1, 2, 3]
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            val content = trimmed.substring(1, trimmed.length - 1).trim()
            if (content.isEmpty()) return mutableListOf<Any?>()
            return content.split(",").map { evaluatePythonExpr(it.trim(), env, functions) }.toMutableList()
        }

        // Binary Operations (+, -, *, /, %, ==, !=, <, >)
        if (trimmed.contains(" + ")) {
            val parts = trimmed.split(" + ", limit = 2)
            val left = evaluatePythonExpr(parts[0], env, functions)
            val right = evaluatePythonExpr(parts[1], env, functions)
            return combineAdd(left, right)
        }
        if (trimmed.contains(" * ")) {
            val parts = trimmed.split(" * ", limit = 2)
            val left = (evaluatePythonExpr(parts[0], env, functions) as? Number)?.toDouble() ?: 0.0
            val right = (evaluatePythonExpr(parts[1], env, functions) as? Number)?.toDouble() ?: 0.0
            val res = left * right
            return if (res % 1 == 0.0) res.toLong() else res
        }
        if (trimmed.contains(" == ")) {
            val parts = trimmed.split(" == ", limit = 2)
            return evaluatePythonExpr(parts[0], env, functions) == evaluatePythonExpr(parts[1], env, functions)
        }
        if (trimmed.contains(" > ")) {
            val parts = trimmed.split(" > ", limit = 2)
            val left = (evaluatePythonExpr(parts[0], env, functions) as? Number)?.toDouble() ?: 0.0
            val right = (evaluatePythonExpr(parts[1], env, functions) as? Number)?.toDouble() ?: 0.0
            return left > right
        }
        if (trimmed.contains(" < ")) {
            val parts = trimmed.split(" < ", limit = 2)
            val left = (evaluatePythonExpr(parts[0], env, functions) as? Number)?.toDouble() ?: 0.0
            val right = (evaluatePythonExpr(parts[1], env, functions) as? Number)?.toDouble() ?: 0.0
            return left < right
        }

        // Function Calls: factorial(6) or len(x)
        if (trimmed.contains("(") && trimmed.endsWith(")")) {
            val openParen = trimmed.indexOf("(")
            val fnName = trimmed.substring(0, openParen).trim()
            val argsStr = trimmed.substring(openParen + 1, trimmed.length - 1).trim()
            val args = if (argsStr.isEmpty()) emptyList() else argsStr.split(",").map { evaluatePythonExpr(it.trim(), env, functions) }

            when (fnName) {
                "len" -> {
                    val target = args.getOrNull(0)
                    if (target is List<*>) return target.size
                    if (target is String) return target.length
                    return 0
                }
                "abs" -> {
                    val num = (args.getOrNull(0) as? Number)?.toDouble() ?: 0.0
                    return Math.abs(num)
                }
                "str" -> return args.getOrNull(0)?.toString() ?: ""
                "int" -> return (args.getOrNull(0)?.toString()?.toDoubleOrNull() ?: 0.0).toLong()
            }
        }

        // Variable Lookup
        if (env.containsKey(trimmed)) {
            return env[trimmed]
        }

        return trimmed
    }

    // ==========================================
    // PSEUDOCODE INTERPRETER
    // ==========================================
    private suspend fun runPseudocode(code: String) {
        val lines = code.lines()
        val env = HashMap<String, Any?>()

        var i = 0
        while (i < lines.size) {
            val raw = lines[i]
            val line = raw.trim()

            if (line.isEmpty() || line.startsWith("//") || line.startsWith("/*")) {
                i++
                continue
            }

            val upperLine = line.uppercase()

            // DISPLAY / PRINT / OUTPUT
            if (upperLine.startsWith("DISPLAY ") || upperLine.startsWith("PRINT ") || upperLine.startsWith("OUTPUT ")) {
                val spaceIdx = line.indexOf(" ")
                val expr = line.substring(spaceIdx + 1).trim()
                val evaluated = evaluatePseudoExpr(expr, env)
                onOutput(formatOutput(evaluated), LogType.STDOUT)
                i++
                continue
            }

            // INPUT / READ
            if (upperLine.startsWith("INPUT ") || upperLine.startsWith("READ ")) {
                val spaceIdx = line.indexOf(" ")
                val varName = line.substring(spaceIdx + 1).trim()
                val promptText = "Enter value for $varName: "
                onOutput(promptText, LogType.INPUT_PROMPT)
                val userInput = onRequestInput(promptText)
                onOutput(userInput, LogType.USER_INPUT)
                env[varName] = userInput
                i++
                continue
            }

            // DECLARE var AS TYPE
            if (upperLine.startsWith("DECLARE ")) {
                val declStr = line.substring(8).trim()
                val parts = declStr.split(" AS ", ignoreCase = true)
                val varName = parts[0].trim()
                env[varName] = ""
                i++
                continue
            }

            // SET var TO val  or  var <- val
            if (upperLine.startsWith("SET ") || line.contains("<-")) {
                if (upperLine.startsWith("SET ")) {
                    val setStr = line.substring(4).trim()
                    val parts = setStr.split(" TO ", ignoreCase = true)
                    if (parts.size == 2) {
                        val varName = parts[0].trim()
                        val valExpr = parts[1].trim()
                        env[varName] = evaluatePseudoExpr(valExpr, env)
                    }
                } else {
                    val parts = line.split("<-")
                    val varName = parts[0].trim()
                    val valExpr = parts[1].trim()
                    env[varName] = evaluatePseudoExpr(valExpr, env)
                }
                i++
                continue
            }

            // FOR EACH item IN list DO
            if (upperLine.startsWith("FOR EACH ") && upperLine.contains(" IN ")) {
                val forHeader = line.substring(9).trim()
                val inParts = forHeader.split(" IN ", ignoreCase = true)
                val varName = inParts[0].trim()
                val listExpr = inParts[1].replace(" DO", "", ignoreCase = true).trim()

                val loopBody = mutableListOf<String>()
                var j = i + 1
                while (j < lines.size && !lines[j].trim().uppercase().startsWith("END FOR")) {
                    loopBody.add(lines[j])
                    j++
                }

                val listObj = evaluatePseudoExpr(listExpr, env)
                if (listObj is List<*>) {
                    for (item in listObj) {
                        env[varName] = item
                        runPseudocodeBlock(loopBody, env)
                    }
                }
                i = j + 1
                continue
            }

            // FOR i FROM start TO end DO
            if (upperLine.startsWith("FOR ") && upperLine.contains(" FROM ") && upperLine.contains(" TO ")) {
                val forHeader = line.substring(4).replace(" DO", "", ignoreCase = true).trim()
                val fromParts = forHeader.split(" FROM ", ignoreCase = true)
                val varName = fromParts[0].trim()
                val rangeParts = fromParts[1].split(" TO ", ignoreCase = true)
                val startVal = (evaluatePseudoExpr(rangeParts[0].trim(), env) as? Number)?.toInt() ?: 0
                val endVal = (evaluatePseudoExpr(rangeParts[1].trim(), env) as? Number)?.toInt() ?: 0

                val loopBody = mutableListOf<String>()
                var j = i + 1
                while (j < lines.size && !lines[j].trim().uppercase().startsWith("END FOR")) {
                    loopBody.add(lines[j])
                    j++
                }

                for (idx in startVal..endVal) {
                    env[varName] = idx
                    runPseudocodeBlock(loopBody, env)
                }
                i = j + 1
                continue
            }

            // IF condition THEN
            if (upperLine.startsWith("IF ") && upperLine.contains(" THEN")) {
                val condExpr = line.substring(3, line.indexOf(" THEN", ignoreCase = true)).trim()
                val ifBody = mutableListOf<String>()
                var j = i + 1
                while (j < lines.size && !lines[j].trim().uppercase().startsWith("END IF")) {
                    ifBody.add(lines[j])
                    j++
                }

                if (isTruthy(evaluatePseudoExpr(condExpr, env))) {
                    runPseudocodeBlock(ifBody, env)
                }
                i = j + 1
                continue
            }

            i++
        }
    }

    private suspend fun runPseudocodeBlock(lines: List<String>, env: MutableMap<String, Any?>) {
        val code = lines.joinToString("\n")
        runPseudocodeSubBlock(code, env)
    }

    private suspend fun runPseudocodeSubBlock(code: String, env: MutableMap<String, Any?>) {
        val lines = code.lines()
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("//")) continue
            val upper = line.uppercase()

            if (upper.startsWith("DISPLAY ") || upper.startsWith("PRINT ") || upper.startsWith("OUTPUT ")) {
                val spaceIdx = line.indexOf(" ")
                val expr = line.substring(spaceIdx + 1).trim()
                onOutput(formatOutput(evaluatePseudoExpr(expr, env)), LogType.STDOUT)
            } else if (upper.startsWith("SET ") || line.contains("<-")) {
                if (upper.startsWith("SET ")) {
                    val parts = line.substring(4).trim().split(" TO ", ignoreCase = true)
                    if (parts.size == 2) {
                        env[parts[0].trim()] = evaluatePseudoExpr(parts[1].trim(), env)
                    }
                } else {
                    val parts = line.split("<-")
                    env[parts[0].trim()] = evaluatePseudoExpr(parts[1].trim(), env)
                }
            }
        }
    }

    private fun evaluatePseudoExpr(expr: String, env: Map<String, Any?>): Any? {
        val trimmed = expr.trim()
        if (trimmed.isEmpty()) return ""

        if ((trimmed.startsWith("\"") && trimmed.endsWith("\"")) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
            return trimmed.substring(1, trimmed.length - 1)
        }

        trimmed.toLongOrNull()?.let { return it }
        trimmed.toDoubleOrNull()?.let { return it }
        if (trimmed.equals("TRUE", ignoreCase = true)) return true
        if (trimmed.equals("FALSE", ignoreCase = true)) return false

        // Array literal: [85, 92, 78]
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            val content = trimmed.substring(1, trimmed.length - 1).trim()
            if (content.isEmpty()) return mutableListOf<Any?>()
            return content.split(",").map { evaluatePseudoExpr(it.trim(), env) }.toMutableList()
        }

        // Concatenation or Addition +
        if (trimmed.contains(" + ")) {
            val parts = trimmed.split(" + ", limit = 2)
            val left = evaluatePseudoExpr(parts[0], env)
            val right = evaluatePseudoExpr(parts[1], env)
            return combineAdd(left, right)
        }

        if (trimmed.contains(" / ")) {
            val parts = trimmed.split(" / ", limit = 2)
            val left = (evaluatePseudoExpr(parts[0], env) as? Number)?.toDouble() ?: 0.0
            val right = (evaluatePseudoExpr(parts[1], env) as? Number)?.toDouble() ?: 1.0
            val res = left / right
            return if (res % 1 == 0.0) res.toLong() else res
        }

        if (trimmed.contains(" >= ")) {
            val parts = trimmed.split(" >= ", limit = 2)
            val left = (evaluatePseudoExpr(parts[0], env) as? Number)?.toDouble() ?: 0.0
            val right = (evaluatePseudoExpr(parts[1], env) as? Number)?.toDouble() ?: 0.0
            return left >= right
        }

        if (env.containsKey(trimmed)) {
            return env[trimmed]
        }

        return trimmed
    }

    // ==========================================
    // LUA INTERPRETER
    // ==========================================
    private suspend fun runLua(code: String) {
        val lines = code.lines()
        val env = HashMap<String, Any?>()

        var i = 0
        while (i < lines.size) {
            val raw = lines[i]
            val line = raw.trim()

            if (line.isEmpty() || line.startsWith("--")) {
                i++
                continue
            }

            // print(...)
            if (line.startsWith("print(") && line.endsWith(")")) {
                val expr = line.substring(6, line.length - 1).trim()
                val evaluated = evaluateLuaExpr(expr, env)
                onOutput(formatOutput(evaluated), LogType.STDOUT)
                i++
                continue
            }

            // io.read(...)
            if (line.contains("io.read(")) {
                val eqIdx = line.indexOf("=")
                var varName = "input_val"
                if (eqIdx > 0) {
                    varName = line.substring(0, eqIdx).replace("local", "").trim()
                }
                val promptText = "Enter input: "
                onOutput(promptText, LogType.INPUT_PROMPT)
                val userInput = onRequestInput(promptText)
                onOutput(userInput, LogType.USER_INPUT)
                env[varName] = userInput
                i++
                continue
            }

            // local var = expr
            if (line.startsWith("local ") && line.contains("=")) {
                val decl = line.substring(6).trim()
                val eqIdx = decl.indexOf("=")
                val varName = decl.substring(0, eqIdx).trim()
                val valExpr = decl.substring(eqIdx + 1).trim()
                env[varName] = evaluateLuaExpr(valExpr, env)
                i++
                continue
            }

            // for i, v in ipairs(table) do
            if (line.startsWith("for ") && line.contains("in ipairs(") && line.endsWith("do")) {
                val header = line.substring(4, line.length - 2).trim()
                val parts = header.split(" in ipairs(")
                val vars = parts[0].split(",").map { it.trim() }
                val idxVar = vars.getOrNull(0) ?: "i"
                val valVar = vars.getOrNull(1) ?: "v"
                val tableExpr = parts[1].replace(")", "").trim()

                val loopBody = mutableListOf<String>()
                var j = i + 1
                while (j < lines.size && lines[j].trim() != "end") {
                    loopBody.add(lines[j])
                    j++
                }

                val tableObj = evaluateLuaExpr(tableExpr, env)
                if (tableObj is List<*>) {
                    tableObj.forEachIndexed { index, item ->
                        env[idxVar] = index + 1
                        env[valVar] = item
                        runLuaBlock(loopBody, env)
                    }
                }
                i = j + 1
                continue
            }

            i++
        }
    }

    private suspend fun runLuaBlock(lines: List<String>, env: MutableMap<String, Any?>) {
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("--")) continue
            if (line.startsWith("print(") && line.endsWith(")")) {
                val expr = line.substring(6, line.length - 1).trim()
                onOutput(formatOutput(evaluateLuaExpr(expr, env)), LogType.STDOUT)
            }
        }
    }

    private fun evaluateLuaExpr(expr: String, env: Map<String, Any?>): Any? {
        val trimmed = expr.trim()
        if (trimmed.isEmpty()) return ""

        if ((trimmed.startsWith("\"") && trimmed.endsWith("\"")) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
            return trimmed.substring(1, trimmed.length - 1)
        }

        trimmed.toLongOrNull()?.let { return it }
        trimmed.toDoubleOrNull()?.let { return it }
        if (trimmed == "true") return true
        if (trimmed == "false") return false

        // Lua string concatenation ..
        if (trimmed.contains(" .. ")) {
            val parts = trimmed.split(" .. ")
            return parts.joinToString("") { evaluateLuaExpr(it, env)?.toString() ?: "" }
        }

        // Table literal: {"Apple", "Banana"}
        if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
            val content = trimmed.substring(1, trimmed.length - 1).trim()
            if (content.isEmpty()) return mutableListOf<Any?>()
            return content.split(",").map { evaluateLuaExpr(it.trim(), env) }.toMutableList()
        }

        // math.sqrt(144)
        if (trimmed.startsWith("math.sqrt(") && trimmed.endsWith(")")) {
            val inner = trimmed.substring(10, trimmed.length - 1)
            val num = (evaluateLuaExpr(inner, env) as? Number)?.toDouble() ?: 0.0
            val res = Math.sqrt(num)
            return if (res % 1 == 0.0) res.toLong() else res
        }

        if (env.containsKey(trimmed)) {
            return env[trimmed]
        }

        return trimmed
    }

    // Helpers
    private fun formatOutput(obj: Any?): String {
        return when (obj) {
            null -> "None"
            is List<*> -> obj.toString()
            else -> obj.toString()
        }
    }

    private fun combineAdd(left: Any?, right: Any?): Any {
        if (left is Number && right is Number) {
            val res = left.toDouble() + right.toDouble()
            return if (res % 1 == 0.0) res.toLong() else res
        }
        return "${left ?: ""}${right ?: ""}"
    }

    private fun isTruthy(value: Any?): Boolean {
        return when (value) {
            null, false, 0, 0.0, "" -> false
            is Collection<*> -> value.isNotEmpty()
            else -> true
        }
    }
}
