package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ExecutionStatus
import com.example.engine.Language
import com.example.engine.LogType
import com.example.engine.TerminalState

@Composable
fun TerminalConsole(
    terminalState: TerminalState,
    language: Language,
    onRunScript: () -> Unit,
    onStopScript: () -> Unit,
    onClearTerminal: () -> Unit,
    onSubmitInput: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val listState = rememberLazyListState()
    var inputFieldValue by remember { mutableStateOf("") }

    // Auto-scroll to bottom whenever new logs arrive
    LaunchedEffect(terminalState.logs.size) {
        if (terminalState.logs.isNotEmpty()) {
            listState.animateScrollToItem(terminalState.logs.size - 1)
        }
    }

    val terminalBg = Color(0xFF0F172A) // Deep slate terminal black

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = terminalBg,
        tonalElevation = 8.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Terminal Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Terminal Icon",
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "TERMINAL (${language.displayName})",
                        color = Color(0xFFF8FAFC),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    // Execution Status Badge
                    val (statusColor, statusText) = when (terminalState.status) {
                        ExecutionStatus.IDLE -> Color(0xFF94A3B8) to "IDLE"
                        ExecutionStatus.RUNNING -> Color(0xFF38BDF8) to "RUNNING..."
                        ExecutionStatus.WAITING_FOR_INPUT -> Color(0xFFFBBF24) to "WAITING FOR INPUT"
                        ExecutionStatus.COMPLETED -> Color(0xFF34D399) to "FINISHED (0)"
                        ExecutionStatus.ERROR -> Color(0xFFF87171) to "ERROR (1)"
                    }

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(statusColor.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(statusColor)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = statusText,
                                color = statusColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Action Controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (terminalState.status == ExecutionStatus.RUNNING || terminalState.status == ExecutionStatus.WAITING_FOR_INPUT) {
                        IconButton(
                            onClick = onStopScript,
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("terminal_stop_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop Script",
                                tint = Color(0xFFF87171)
                            )
                        }
                    } else {
                        IconButton(
                            onClick = onRunScript,
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("terminal_run_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Run Script",
                                tint = Color(0xFF34D399)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            val fullText = terminalState.logs.joinToString("\n") { it.message }
                            if (fullText.isNotEmpty()) {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Terminal Logs", fullText)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Terminal logs copied!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("terminal_copy_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Logs",
                            tint = Color(0xFF94A3B8)
                        )
                    }

                    IconButton(
                        onClick = onClearTerminal,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("terminal_clear_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ClearAll,
                            contentDescription = "Clear Terminal",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                }
            }

            // Terminal Logs Area
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                if (terminalState.logs.isEmpty()) {
                    item {
                        Text(
                            text = "Terminal ready. Tap 'Run' to execute script.",
                            color = Color(0xFF64748B),
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                }

                items(terminalState.logs) { log ->
                    val textColor = when (log.type) {
                        LogType.STDOUT -> Color(0xFFE2E8F0)
                        LogType.STDERR -> Color(0xFFF87171)
                        LogType.SYSTEM -> Color(0xFF94A3B8)
                        LogType.INPUT_PROMPT -> Color(0xFFFBBF24)
                        LogType.USER_INPUT -> Color(0xFF38BDF8)
                    }

                    Text(
                        text = log.message,
                        color = textColor,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (log.type == LogType.INPUT_PROMPT || log.type == LogType.STDERR) FontWeight.Bold else FontWeight.Normal,
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(vertical = 1.dp)
                    )
                }
            }

            // Interactive Input Bar
            AnimatedVisibility(visible = terminalState.status == ExecutionStatus.WAITING_FOR_INPUT) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E293B))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = ">",
                        color = Color(0xFFFBBF24),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )

                    OutlinedTextField(
                        value = inputFieldValue,
                        onValueChange = { inputFieldValue = it },
                        placeholder = {
                            Text(
                                "Type input & press send...",
                                color = Color(0xFF64748B),
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFBBF24),
                            unfocusedBorderColor = Color(0xFF475569),
                            focusedTextColor = Color(0xFFF8FAFC),
                            unfocusedTextColor = Color(0xFFF8FAFC)
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (inputFieldValue.isNotBlank()) {
                                    onSubmitInput(inputFieldValue)
                                    inputFieldValue = ""
                                }
                            }
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("terminal_input_field")
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    Button(
                        onClick = {
                            if (inputFieldValue.isNotBlank()) {
                                onSubmitInput(inputFieldValue)
                                inputFieldValue = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFBBF24),
                            contentColor = Color(0xFF0F172A)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("terminal_input_submit_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send Input",
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
