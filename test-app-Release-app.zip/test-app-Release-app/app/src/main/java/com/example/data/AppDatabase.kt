package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [ScriptEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scriptDao(): ScriptDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "code_editor_db"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialScripts(database.scriptDao())
                    }
                }
            }

            suspend fun populateInitialScripts(dao: ScriptDao) {
                // Python Samples
                dao.insertScript(
                    ScriptEntity(
                        title = "Python: Calculator & Loops",
                        language = "python",
                        code = """# Python interactive calculator & loop demo
print("=== Python Script Demo ===")

name = input("Enter your name: ")
print(f"Hello, {name}! Welcome to Python.")

print("\n--- Counting Loop ---")
for i in range(1, 6):
    square = i * i
    print(f"Number {i}^2 = {square}")

# Simple Function
def add_numbers(a, b):
    return a + b

num1 = 15
num2 = 27
result = add_numbers(num1, num2)
print(f"\nSum of {num1} + {num2} = {result}")

# List comprehension simulation
numbers = [1, 2, 3, 4, 5, 10, 20]
even_numbers = [n for n in numbers if n % 2 == 0]
print(f"Filtered Even Numbers: {even_numbers}")
""",
                        isTemplate = true
                    )
                )

                dao.insertScript(
                    ScriptEntity(
                        title = "Python: Fibonacci & Factorial",
                        language = "python",
                        code = """# Python Math Algorithms
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

def fibonacci(limit):
    a, b = 0, 1
    sequence = []
    while a < limit:
        sequence.append(a)
        a, b = b, a + b
    return sequence

print("Factorial of 6:", factorial(6))
print("Fibonacci numbers under 50:", fibonacci(50))
""",
                        isTemplate = true
                    )
                )

                // Pseudocode Samples
                dao.insertScript(
                    ScriptEntity(
                        title = "Pseudocode: Student Grade Evaluator",
                        language = "pseudocode",
                        code = """// Standard Academic Pseudocode Script
DISPLAY "=== Student Grade Evaluator ==="

DECLARE studentName AS STRING
INPUT studentName

DECLARE score AS INTEGER
DISPLAY "Enter exam score (0-100): "
INPUT score

IF score >= 90 THEN
    SET grade TO "A"
ELSE IF score >= 80 THEN
    SET grade TO "B"
ELSE IF score >= 70 THEN
    SET grade TO "C"
ELSE IF score >= 60 THEN
    SET grade TO "D"
ELSE
    SET grade TO "F"
END IF

DISPLAY "Student: " + studentName
DISPLAY "Grade: " + grade

// Array Iteration
DECLARE scores AS LIST
SET scores TO [85, 92, 78, 95, 88]

DECLARE total TO 0
FOR EACH s IN scores DO
    SET total TO total + s
END FOR

DECLARE average TO total / 5
DISPLAY "Class Average: " + average
""",
                        isTemplate = true
                    )
                )

                dao.insertScript(
                    ScriptEntity(
                        title = "Pseudocode: Bubble Sort",
                        language = "pseudocode",
                        code = """// Bubble Sort in Pseudocode
DISPLAY "--- Bubble Sort Demo ---"

SET numbers TO [64, 34, 25, 12, 22, 11, 90]
DISPLAY "Original List: " + numbers

DECLARE n TO 7
FOR i FROM 0 TO n - 1 DO
    FOR j FROM 0 TO n - i - 2 DO
        IF numbers[j] > numbers[j + 1] THEN
            // Swap elements
            SET temp TO numbers[j]
            SET numbers[j] TO numbers[j + 1]
            SET numbers[j + 1] TO temp
        END IF
    END FOR
END FOR

DISPLAY "Sorted List: " + numbers
""",
                        isTemplate = true
                    )
                )

                // Lua Samples
                dao.insertScript(
                    ScriptEntity(
                        title = "Lua: Table Operations & Functions",
                        language = "lua",
                        code = """-- Lua Script Demo
print("=== Lua Script Demo ===")

local user_name = io.read("Enter your developer handle: ")
print("Welcome to Lua, " .. user_name .. "!")

-- Tables (Lua primary data structure)
local fruits = {"Apple", "Banana", "Cherry", "Dragonfruit"}

print("\nFruit Inventory:")
for i, fruit in ipairs(fruits) do
    print(i .. ". " .. fruit)
end

-- Custom Function
local function calculate_area(width, height)
    return width * height
end

local w = 12
local h = 8
local area = calculate_area(w, h)
print("\nRectangle Area (" .. w .. "x" .. h .. "): " .. area)

-- Conditional logic
if area > 50 then
    print("Status: Large surface area")
else
    print("Status: Compact area")
end
""",
                        isTemplate = true
                    )
                )

                dao.insertScript(
                    ScriptEntity(
                        title = "Lua: Math & Table Filter",
                        language = "lua",
                        code = """-- Lua Math and Utility functions
print("--- Lua Math Utilities ---")

local numbers = {10, 25, 3, 44, 18, 92, 7}
local max_val = numbers[1]
local min_val = numbers[1]

for _, val in ipairs(numbers) do
    if val > max_val then
        max_val = val
    end
    if val < min_val then
        min_val = val
    end
end

print("Max Value: " .. max_val)
print("Min Value: " .. min_val)
print("Square root of 144: " .. math.sqrt(144))
""",
                        isTemplate = true
                    )
                )
            }
        }
    }
}
