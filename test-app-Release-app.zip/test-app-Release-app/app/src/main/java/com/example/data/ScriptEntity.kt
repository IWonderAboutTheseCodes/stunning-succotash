package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scripts")
data class ScriptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val language: String, // "python", "pseudocode", "lua"
    val code: String,
    val updatedAt: Long = System.currentTimeMillis(),
    val isTemplate: Boolean = false
)
