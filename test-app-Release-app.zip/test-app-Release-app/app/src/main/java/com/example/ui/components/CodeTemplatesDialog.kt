package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.IntegrationInstructions
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.Language

data class CodeTemplate(
    val title: String,
    val description: String,
    val language: Language,
    val code: String
)

val STARTER_TEMPLATES = listOf(
    // Python Templates
    CodeTemplate(
        title = "Python: Interactive Input & Calculator",
        description = "User input, arithmetic operations, and list comprehensions.",
        language = Language.PYTHON,
        code = """# Python Calculator & Input Demo
print("=== Python Calculator ===")

name = input("Enter your name: ")
print(f"Hello {name}!")

a = 24
b = 8
print(f"Sum: {a + b}")
print(f"Product: {a * b}")

# Square loop
numbers = [1, 2, 3, 4, 5]
print("Numbers:", numbers)
"""
    ),
    CodeTemplate(
        title = "Python: Fibonacci & Factorial",
        description = "Functions, recursion, and sequence generator algorithms.",
        language = Language.PYTHON,
        code = """# Python Math Algorithms
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

def fibonacci(limit):
    a, b = 0, 1
    seq = []
    while a < limit:
        seq.append(a)
        a, b = b, a + b
    return seq

print("Factorial of 5:", factorial(5))
print("Fibonacci under 30:", fibonacci(30))
"""
    ),

    // Pseudocode Templates
    CodeTemplate(
        title = "Pseudocode: Academic Grade Evaluator",
        description = "AP CS Standard Pseudocode with IF/THEN/ELSE IF and List loops.",
        language = Language.PSEUDOCODE,
        code = """// Standard Academic Pseudocode
DISPLAY "=== Student Grade Evaluator ==="

DECLARE studentName AS STRING
INPUT studentName

DECLARE score AS INTEGER
SET score TO 88

IF score >= 90 THEN
    SET grade TO "A"
ELSE IF score >= 80 THEN
    SET grade TO "B"
ELSE
    SET grade TO "C"
END IF

DISPLAY "Student: " + studentName
DISPLAY "Grade: " + grade
"""
    ),
    CodeTemplate(
        title = "Pseudocode: Bubble Sort Algorithm",
        description = "Nested FOR loops and element swap in Pseudocode.",
        language = Language.PSEUDOCODE,
        code = """// Bubble Sort in Pseudocode
DISPLAY "--- Bubble Sort ---"

SET numbers TO [64, 34, 25, 12, 22]
DISPLAY "Original List: " + numbers

DECLARE n TO 5
FOR i FROM 0 TO n - 1 DO
    FOR j FROM 0 TO n - i - 2 DO
        IF numbers[j] > numbers[j + 1] THEN
            SET temp TO numbers[j]
            SET numbers[j] TO numbers[j + 1]
            SET numbers[j + 1] TO temp
        END IF
    END FOR
END FOR

DISPLAY "Sorted List: " + numbers
"""
    ),

    // Lua Templates
    CodeTemplate(
        title = "Lua: Table Data Structures & Iteration",
        description = "Tables, ipairs loop, and custom functions in Lua.",
        language = Language.LUA,
        code = """-- Lua Script Demo
print("=== Lua Table Demo ===")

local fruits = {"Apple", "Banana", "Cherry", "Mango"}

print("Fruit List:")
for i, item in ipairs(fruits) do
    print(i .. ". " .. item)
end

local function square(x)
    return x * x
end

print("Square of 9: " .. square(9))
"""
    ),
    CodeTemplate(
        title = "Lua: Math Utilities & Min/Max Finder",
        description = "Table array filtering and Lua math library calls.",
        language = Language.LUA,
        code = """-- Lua Math Utilities
print("--- Lua Math ---")

local data = {12, 45, 2, 99, 34}
local max_val = data[1]

for _, val in ipairs(data) do
    if val > max_val then
        max_val = val
    end
end

print("Max Value in table: " .. max_val)
print("Square root of 81: " .. math.sqrt(81))
"""
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CodeTemplatesDialog(
    onDismiss: () -> Unit,
    onSelectTemplate: (CodeTemplate) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val languages = listOf(Language.PYTHON, Language.PSEUDOCODE, Language.LUA)
    val currentLang = languages[selectedTab]
    val filteredTemplates = STARTER_TEMPLATES.filter { it.language == currentLang }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Lightbulb,
                    contentDescription = "Templates",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = "Code Templates",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Pick a ready-to-run template to jumpstart your script:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                TabRow(selectedTabIndex = selectedTab) {
                    languages.forEachIndexed { index, lang ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { Text(lang.displayName) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.height(280.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredTemplates) { template ->
                        Card(
                            onClick = {
                                onSelectTemplate(template)
                                onDismiss()
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainer
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("template_card_${template.title.lowercase().replace(" ", "_")}")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = template.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = template.description,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("close_templates_btn")
            ) {
                Text("Close")
            }
        }
    )
}
